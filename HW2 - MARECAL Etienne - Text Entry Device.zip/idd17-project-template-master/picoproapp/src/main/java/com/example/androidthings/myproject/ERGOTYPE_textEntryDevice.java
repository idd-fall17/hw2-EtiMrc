package com.example.androidthings.myproject;

import android.os.SystemClock;

import com.google.android.things.pio.Gpio;

public class ERGOTYPE_textEntryDevice extends SimplePicoPro {

    //initiallize global variables
    long Time=0;
    int previousButton=0;
    int buttons=-1;
    char Letter=' ';
    int currentChar=-1;

    //Create letter array based on buttons & # times pressed
    char letters[][]={{'A','B','C'},{'D','E','F'},{'G','H','I'},{'J','K','L'},{'M','N','O'},{'P','Q','R'},{'S','T','U'},{'V','W','X'},{'Y','Z'}};


    @Override
    public void setup() {
        //set two GPIOs to input
        pinMode(GPIO_128,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_128,Gpio.EDGE_BOTH);

        pinMode(GPIO_39,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_39,Gpio.EDGE_BOTH);

        pinMode(GPIO_37,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_37,Gpio.EDGE_BOTH);

        pinMode(GPIO_35,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_35,Gpio.EDGE_BOTH);

        pinMode(GPIO_34,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_34,Gpio.EDGE_BOTH);

        pinMode(GPIO_33,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_33,Gpio.EDGE_BOTH);

        pinMode(GPIO_32,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_32,Gpio.EDGE_BOTH);

        pinMode(GPIO_10,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_10,Gpio.EDGE_BOTH);

        pinMode(GPIO_172,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_172,Gpio.EDGE_BOTH);

        pinMode(GPIO_173,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_173,Gpio.EDGE_BOTH);

        pinMode(GPIO_174,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_174,Gpio.EDGE_BOTH);

        pinMode(GPIO_175,Gpio.DIRECTION_IN);
        setEdgeTrigger(GPIO_175,Gpio.EDGE_BOTH);
    }

    @Override
    public void loop() {
        long delay = millis()-Time;
        if (delay>400 && Time!=0) {
            buttons = -1;
            Time = 0;
            currentChar = -1;
            printCharacterToScreen(Letter);
        }
    }

    @Override
    void digitalEdgeEvent(Gpio pin, boolean value) {
        println("digitalEdgeEvent"+pin+", "+value);
        // when 128 goes from LOW to HIGH
        // this is on button button release for pull-up resistors

        if(pin==GPIO_128 && value==HIGH) {
            Time=millis();
            buttons=0;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        //when 39 goes from HIGH to HIGH
        else if (pin==GPIO_39 && value==HIGH) {
            // This pin apparently does not work
        }

        else if (pin==GPIO_37 && value==HIGH) {
            Time=millis();
            buttons=1;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];        }

        else if (pin==GPIO_35 && value==HIGH) {
            Time = millis();
            buttons=2;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        else if (pin==GPIO_34 && value==HIGH) {
            Time = millis();
            buttons=3;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        else if (pin==GPIO_33 && value==HIGH) {
            Time = millis();
            buttons=4;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        else if (pin==GPIO_32 && value==HIGH) {
            Time = millis();
            buttons=5;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        else if (pin==GPIO_10 && value==HIGH) {
            Time = millis();
            buttons=6;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        else if (pin==GPIO_172 && value==HIGH) {
            Time = millis();
            buttons=7;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }

        else if (pin==GPIO_173 && value==HIGH) {
            // This pin apparently does not work
        }

        else if (pin==GPIO_174 && value==HIGH) {
            printCharacterToScreen(' ');
        }

        else if (pin==GPIO_175 && value==HIGH) {
            Time = millis();
            buttons=8;
            currentChar=currentChar+1;
            Letter=letters[buttons][currentChar];
        }
    }

}
