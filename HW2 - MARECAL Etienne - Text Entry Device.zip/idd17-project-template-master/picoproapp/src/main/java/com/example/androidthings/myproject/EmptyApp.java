package com.example.androidthings.myproject;

/**
 * Minimal empty example - clone this and add your code.
 * Created by bjoern on 9/1/17.
 */

public class EmptyApp extends SimplePicoPro {
    @Override
    public void setup() {

    }

    @Override
    public void loop() {

    }
}
